const tombolGroupTamu = document.querySelector("#tombol-group-tamu")
const tamu1 = document.querySelector("#tamu1");
const tamu2 = document.querySelector("#tamu2");
const tamu3 = document.querySelector("#tamu3");
const tamu4 = document.querySelector("#tamu4");
const tombolTamu1 = document.querySelector("#tombol-tamu1")
const tombolTamu2 = document.querySelector("#tombol-tamu2")
const tombolTamu3 = document.querySelector("#tombol-tamu3")
const tombolTamu4 = document.querySelector("#tombol-tamu4")
const bgtamu = document.querySelector("#bgtamu");

function saklarGroupTamu(){
    if (tombolGroupTamu.checked == true){
        tamu1.src = "on.png";
        tamu2.src = "on.png";
        tamu3.src = "on.png";
        tamu4.src = "on.png";
        tombolTamu1.checked = true;
        tombolTamu2.checked = true;
        tombolTamu3.checked = true;
        tombolTamu4.checked = true;
        bgtamu.classList.add("active");
    }else if (tombolGroupTamu.checked == false) {
        tamu1.src = "off.png";
        tamu2.src = "off.png";
        tamu3.src = "off.png";
        tamu4.src = "off.png";
        tombolTamu1.checked = false;
        tombolTamu2.checked = false;
        tombolTamu3.checked = false;
        tombolTamu4.checked = false;
        bgtamu.classList.remove("active");
    }
}
function saklarTamu1(){
    if(tombolTamu1.checked==true){
        tamu1.src = "on.png";
        bgtamu.classList.add("active");
        if (tombolTamu1.checked==true && tombolTamu2.checked==true && tombolTamu3.checked==true && tombolTamu4.checked==true){
            tombolGroupTamu.checked=true;
        }
    }
    else{
        tombolGroupTamu.checked = false;
        if (tombolGroupTamu.checked == false) {
            tamu1.src = "off.png";
            tombolTamu1.checked = false;
        }
        if (tombolTamu1.checked==false && tombolTamu2.checked==false && tombolTamu3.checked==false && tombolTamu4.checked==false){
            bgtamu.classList.remove("active");
        }
    }
}

function saklarTamu2(){
    if(tombolTamu2.checked==true){
        tamu2.src = "on.png";
        bgtamu.classList.add("active");
        if (tombolTamu1.checked==true && tombolTamu2.checked==true && tombolTamu3.checked==true && tombolTamu4.checked==true){
            tombolGroupTamu.checked=true;
        }
    }
    else{
        tombolGroupTamu.checked = false;
        if (tombolGroupTamu.checked == false) {
            tamu2.src = "off.png";
            tombolTamu2.checked = false;
        }
        if (tombolTamu1.checked==false && tombolTamu2.checked==false && tombolTamu3.checked==false && tombolTamu4.checked==false){
            bgtamu.classList.remove("active");
        }
    }
}

function saklarTamu3(){
    if(tombolTamu3.checked==true){
        tamu3.src = "on.png";
        bgtamu.classList.add("active");
        if (tombolTamu1.checked==true && tombolTamu2.checked==true && tombolTamu3.checked==true && tombolTamu4.checked==true){
            tombolGroupTamu.checked=true;
        }
    }
    else{
        tombolGroupTamu.checked = false;
        if (tombolGroupTamu.checked == false) {
            tamu3.src = "off.png";
            tombolTamu3.checked = false;
        }
        if (tombolTamu1.checked==false && tombolTamu2.checked==false && tombolTamu3.checked==false && tombolTamu4.checked==false){
            bgtamu.classList.remove("active");
        }
    }
}

function saklarTamu4(){
    if(tombolTamu4.checked==true){
        tamu4.src = "on.png";
        bgtamu.classList.add("active");
        if (tombolTamu1.checked==true && tombolTamu2.checked==true && tombolTamu3.checked==true && tombolTamu4.checked==true){
            tombolGroupTamu.checked=true;
        }
    }
    else{
        tombolGroupTamu.checked = false;
        if (tombolGroupTamu.checked == false) {
            tamu4.src = "off.png";
            tombolTamu4.checked = false;
        }
        if (tombolTamu1.checked==false && tombolTamu2.checked==false && tombolTamu3.checked==false && tombolTamu4.checked==false){
            bgtamu.classList.remove("active");
        }
    }
}