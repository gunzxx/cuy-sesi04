const tombolGroupTidur = document.querySelector("#tombol-group-tidur")
const tidur1 = document.querySelector("#tidur1");
const tidur2 = document.querySelector("#tidur2");
const tombolTidur1 = document.querySelector("#tombol-tidur1")
const tombolTidur2 = document.querySelector("#tombol-tidur2")
const bgtidur = document.querySelector("#bgtidur");

function saklarGroupTidur(){
    if (tombolGroupTidur.checked == true){
        tidur1.src = "on.png";
        tidur2.src = "on.png";
        tombolTidur1.checked = true;
        tombolTidur2.checked = true;
        bgtidur.classList.add("active");
    }else if (tombolGroupTidur.checked == false) {
        tidur1.src = "off.png";
        tidur2.src = "off.png";
        tombolTidur1.checked = false;
        tombolTidur2.checked = false;
        bgtidur.classList.remove("active");
    }
}
function saklarTidur1(){
    if(tombolTidur1.checked==true){
        bgtidur.classList.add("active");
        tidur1.src = "on.png";
        if (tombolTidur1.checked==true && tombolTidur2.checked==true){
            tombolGroupTidur.checked=true;
        }
    }
    else{
        tombolGroupTidur.checked = false;
        if (tombolGroupTidur.checked == false) {
            tidur1.src = "off.png";
            tombolTidur1.checked = false;
        }
        if (tombolTidur1.checked==false && tombolTidur2.checked==false){
            bgtidur.classList.remove("active");
        }
    }
}

function saklarTidur2(){
    if(tombolTidur2.checked==true){
        bgtidur.classList.add("active");
        tidur2.src = "on.png";
        if (tombolTidur1.checked==true && tombolTidur2.checked==true){
            tombolGroupTidur.checked=true;
        }
    }
    else{
        tombolGroupTidur.checked = false;
        if (tombolGroupTidur.checked == false) {
            tidur2.src = "off.png";
            tombolTidur2.checked = false;
        }
        if (tombolTidur1.checked==false && tombolTidur2.checked==false){
            bgtidur.classList.remove("active");
        }
    }
}