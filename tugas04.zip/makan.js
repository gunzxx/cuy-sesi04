const tombolGroupMakan = document.querySelector("#tombol-group-makan");
const makan1 = document.querySelector("#makan1");
const tombolMakan1 = document.querySelector("#tombol-makan1");
const bgmakan = document.querySelector("#bgmakan");

function saklarGroupMakan(){
    if (tombolGroupMakan.checked == true){
        makan1.src = "on.png";
        tombolMakan1.checked = true;
        // console.log(bgmakan)
        bgmakan.classList.add("active");
    }else if (tombolGroupMakan.checked == false) {
        makan1.src = "off.png";
        tombolMakan1.checked = false;
        bgmakan.classList.remove("active");
    }
}
function saklarMakan1(){
    if(tombolMakan1.checked==true){
        makan1.src = "on.png";
        tombolGroupMakan.checked=true;
        bgmakan.classList.add("active");
    }
    else{
        bgmakan.classList.remove("active");
        tombolGroupMakan.checked = false;
        if (tombolGroupMakan.checked == false) {
            makan1.src = "off.png";
            tombolMakan1.checked = false;
        }
    }
}


// function saklarKeluarga2(){
//     if(tombolMakan2.checked==true){
//         keluarga2.src = "on.png";
//     }
//     else{
//         tombolGroupMakan.checked = false;
//         if (tombolGroupMakan.checked == false) {
//             keluarga1.src = "off.png";
//             tombolMakan1.checked = false;
//         }
//     }
// }
// function saklarKeluarga3(){
//     if(tombolMakan3.checked==true){
//         keluarga3.src = "on.png";
//     }
//     else{
//         tombolGroupMakan.checked = false;
//         if (tombolGroupMakan.checked == false) {
//             keluarga1.src = "off.png";
//             tombolMakan1.checked = false;
//         }
//     }
// }




