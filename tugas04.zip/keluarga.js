const tombolGroupKeluarga = document.querySelector("#tombol-group-keluarga")
const keluarga1 = document.querySelector("#keluarga1");
const keluarga2 = document.querySelector("#keluarga2");
const keluarga3 = document.querySelector("#keluarga3");
const tombolKeluarga1 = document.querySelector("#tombol-keluarga1");
const tombolKeluarga2 = document.querySelector("#tombol-keluarga2");
const tombolKeluarga3 = document.querySelector("#tombol-keluarga3");
const bgKeluarga = document.querySelector("#bgkeluarga");

function saklarGroupKeluarga(){
    if (tombolGroupKeluarga.checked == true){
        keluarga1.src = "on.png";
        keluarga2.src = "on.png";
        keluarga3.src = "on.png";
        tombolKeluarga1.checked = true;
        tombolKeluarga2.checked = true;
        tombolKeluarga3.checked = true;
        bgKeluarga.classList.add("active");
    }else if (tombolGroupKeluarga.checked == false) {
        keluarga1.src = "off.png";
        keluarga2.src = "off.png";
        keluarga3.src = "off.png";
        tombolKeluarga1.checked = false;
        tombolKeluarga2.checked = false;
        tombolKeluarga3.checked = false;
        bgKeluarga.classList.remove("active");
    }
}
function saklarKeluarga1(){
    if(tombolKeluarga1.checked==true){
        keluarga1.src = "on.png";
        bgKeluarga.classList.add("active");
        if (tombolKeluarga1.checked==true && tombolKeluarga2.checked==true && tombolKeluarga3.checked==true){
            tombolGroupKeluarga.checked=true;
        }
    }
    else{
        tombolGroupKeluarga.checked = false;
        if (tombolGroupKeluarga.checked == false) {
            keluarga1.src = "off.png";
            tombolKeluarga1.checked = false;
        }
        if (tombolKeluarga1.checked==false && tombolKeluarga2.checked==false && tombolKeluarga3.checked==false){
            bgKeluarga.classList.remove("active");
        }
    }
}
function saklarKeluarga2(){
    if(tombolKeluarga2.checked==true){
        keluarga2.src = "on.png";
        bgKeluarga.classList.add("active");
        if (tombolKeluarga1.checked==true && tombolKeluarga2.checked==true && tombolKeluarga3.checked==true){
            tombolGroupKeluarga.checked=true;
        }
    }
    else{
        tombolGroupKeluarga.checked = false;
        if (tombolGroupKeluarga.checked == false) {
            keluarga2.src = "off.png";
            tombolKeluarga2.checked = false;
        }
        if (tombolKeluarga1.checked==false && tombolKeluarga2.checked==false && tombolKeluarga3.checked==false){
            bgKeluarga.classList.remove("active");
        }
    }
}
function saklarKeluarga3(){
    if(tombolKeluarga3.checked==true){
        keluarga3.src = "on.png";
        bgKeluarga.classList.add("active");
        if (tombolKeluarga1.checked==true && tombolKeluarga2.checked==true && tombolKeluarga3.checked==true){
            tombolGroupKeluarga.checked=true;
        }
    }
    else{
        tombolGroupKeluarga.checked = false;
        if (tombolGroupKeluarga.checked == false) {
            keluarga3.src = "off.png";
            tombolKeluarga3.checked = false;
        }
        if (tombolKeluarga1.checked==false && tombolKeluarga2.checked==false && tombolKeluarga3.checked==false){
            bgKeluarga.classList.remove("active");
        }
    }
}





